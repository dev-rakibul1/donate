import React from "react";
import PaymentsTabs from "../../paymentTabs/PaymentsTabs";

const Payment = () => {
  return (
    <div>
      <PaymentsTabs />
    </div>
  );
};

export default Payment;
