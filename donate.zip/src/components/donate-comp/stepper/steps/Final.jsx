import React from "react";
import { FaCheck } from "react-icons/fa";
import { Link } from "react-router-dom";
import Button from "../../../../typography/Button";

const Final = () => {
  return (
    <div className="flex items-center justify-center">
      <div className="flex items-center justify-center flex-col">
        <div className="w-12 h-12 rounded-full bg-green-600 text-white text-center flex items-center justify-center">
          <FaCheck />
        </div>
        <h2 className="text-green-600 font-semibold text-xl">
          Congratulations
        </h2>
        <h3>Your payment is successful!</h3>
        <Link to="/">
          {" "}
          <Button>close</Button>
        </Link>
      </div>
    </div>
  );
};

export default Final;
