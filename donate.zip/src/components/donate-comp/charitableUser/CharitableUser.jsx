import React, { useState } from "react";

import Stepper from "../stepper/Stepper";
import StepperControl from "../stepper/StepperControl";
import Account from "../stepper/steps/Account";
import Final from "../stepper/steps/Final";
import Payment from "../stepper/steps/Payment";
import { StepperContext } from "../stepper/steps/StepperContext";

const CharitableUser = () => {
  const [currentStep, setCurrentSetp] = useState(1);
  const [userData, setUserData] = useState("");
  const [finalData, setFinalData] = useState([]);

  const steps = ["User information", "Billing Information", "Complete"];

  const displaySteps = (step) => {
    switch (step) {
      case 1:
        return <Account />;
      case 2:
        return <Payment />;
      case 3:
        return <Final />;
      default:
    }
  };

  const handleClick = (direction) => {
    let newStep = currentStep;

    direction === "next" ? newStep++ : newStep--;
    newStep > 0 && newStep <= steps.length && setCurrentSetp(newStep);
  };

  return (
    <div className="max-w-[70%] mx-auto">
      <h2 className="text-center text-2xl font-semibold">Donate information</h2>
      <div className="md:1/2 mx-auto shadow-xl rounded-2xl pb-2 bg-white">
        <div className="container horizontal mt-5">
          <Stepper steps={steps} currentStep={currentStep} />

          <div className="my-10 p-10">
            <StepperContext.Provider
              value={{
                userData,
                setUserData,
                finalData,
                setFinalData,
              }}
            >
              {displaySteps(currentStep)}
            </StepperContext.Provider>
          </div>
        </div>
        {currentStep !== steps.length && (
          <StepperControl
            handleClick={handleClick}
            steps={steps}
            currentStep={currentStep}
          />
        )}
      </div>
    </div>
  );
};

export default CharitableUser;
